package com.pirate.jackmonty.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Result {

    private boolean switched;
    private boolean stayed;

    public Result() {

    }
}

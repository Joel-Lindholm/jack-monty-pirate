package com.pirate.jackmonty.exception;

public class BadNbrOfIslandsException extends Exception {

    public BadNbrOfIslandsException(String message) {
        super(message);
    }
}

<template>
  <v-app>
    <v-main>
      <JackMontySimulation />
    </v-main>
  </v-app>
</template>

<script setup lang="ts">
  import JackMontySimulation from '@/components/JackMontySimulation.vue'
</script>

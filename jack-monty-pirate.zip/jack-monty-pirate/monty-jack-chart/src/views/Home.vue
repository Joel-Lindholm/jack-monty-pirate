<template>
  <HelloWorld />
</template>

<script lang="ts" setup>
  import HelloWorld from '@/components/JackMontySimulation.vue'
</script>

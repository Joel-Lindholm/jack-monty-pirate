# Jack monty chart. 

Small test project to get a chart for the simulations

Starts at localhost:3000

## Project setup

```
# npm
npm install
npm run dev

```

